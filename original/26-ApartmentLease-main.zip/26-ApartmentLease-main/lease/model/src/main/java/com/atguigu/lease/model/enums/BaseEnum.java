package com.atguigu.lease.model.enums;

public interface BaseEnum
{

    Integer getCode();

    String getName();
}
