export namespace HandleData {
  export type MessageType = '' | 'success' | 'warning' | 'info' | 'error'
}
