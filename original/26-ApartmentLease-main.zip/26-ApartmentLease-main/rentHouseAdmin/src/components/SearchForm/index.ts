import SearchForm from './src/SearchForm.vue'
export { SearchForm }
export default SearchForm
