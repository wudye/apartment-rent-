export const TOKEN_KEY = 'TOKEN__'

export const USER_INFO_KEY = 'USER__INFO__'
